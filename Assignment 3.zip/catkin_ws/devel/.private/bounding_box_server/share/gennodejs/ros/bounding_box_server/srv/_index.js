
"use strict";

let GetBoundingBox = require('./GetBoundingBox.js')

module.exports = {
  GetBoundingBox: GetBoundingBox,
};
