
"use strict";

let ObjectRecognition = require('./ObjectRecognition.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');

module.exports = {
  ObjectRecognition: ObjectRecognition,
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
};
