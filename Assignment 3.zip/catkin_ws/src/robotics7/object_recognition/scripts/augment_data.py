import csv
import cv2
import os
import numpy as np
import matplotlib.pyplot as plt

path = os.path.join(os.environ["HOME"], "data/training")
labels = ["redbox", "greenbox", "bluebox", "yellowbox", "purplebox"]

# Augmentatioin parameters
AUGS_PER_IMG = 10
CROP_SHIFT = 15
RAND_BRIGHTNESS = 50

def random_crop(img, top, bottom, left, right):
    x_shift = np.random.randint(-CROP_SHIFT, CROP_SHIFT)
    y_shift = np.random.randint(-CROP_SHIFT, CROP_SHIFT)

    top += y_shift
    bottom += y_shift
    left += x_shift
    right += x_shift

    max_x = img.shape[1]
    max_y = img.shape[0]

    top = min(top, max_y)
    bottom = max(bottom, 0)
    left = max(left, 0)
    right = min(right, max_x)

    return top, bottom, left, right


def random_brightness(img):
    hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    new_img = hsv_img.copy()

    shift_value = np.random.randint(-RAND_BRIGHTNESS, RAND_BRIGHTNESS)
    
    for y in range(img.shape[0]):
        for x in range(img.shape[1]):
            old_value = new_img[y,x,2]
            new_value = np.clip(old_value + shift_value, 0, 255)
            new_img[y,x,2] = new_value

    return cv2.cvtColor(new_img, cv2.COLOR_HSV2BGR)

for label in labels:
  print "Processing " + label + "..."
  data_path = os.path.join(path, label)

  aug_data_path = os.path.join(path, label + "_augmented")
  if not os.path.exists(aug_data_path):
    os.makedirs(aug_data_path)
  
  with open(os.path.join(data_path, "data.csv")) as f:
    csv_reader = csv.reader(f)
    img_num = 0

    for row_num, row in enumerate(csv_reader):
        print "Processing ", row[0]
        for aug in range(AUGS_PER_IMG):
          image_path = row[0]
          top = int(row[1])
          bottom = int(row[2])
          left = int(row[3])
          right = int(row[4])

          image = cv2.imread(image_path)
          top, bottom, left, right = random_crop(image, top, bottom, left, right)
          aug_img = random_brightness(image)
          aug_img = aug_img[top:bottom,left:right]
          cv2.imwrite(os.path.join(aug_data_path, label + str(img_num) + ".jpg"), aug_img)

          img_num += 1

          #cv2.rectangle(aug_img, (left, top), (right, bottom), (255, 0, 0))
          # cv2.imshow("image", aug_img)
          # key = cv2.waitKey(0) & 0xFF # Will wait for any keypress to continue, pressing 'q' will quit the program

          # if key == ord("q"):
          #   exit()
