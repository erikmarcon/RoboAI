#!/usr/bin/env python3
import rospy 
import os 
from point_cloud_functions.srv import GetObjectROI, GetObjectROIRequest
from image_converter import ImageConverter
import cv2
from sensor_msgs.msg import Image
import numpy as np
import tensorflow as tf 
from tensorflow.python.saved_model import tag_constants
import actionlib
from object_recognition.msg import ObjectRecognitionAction, ObjectRecognitionResult
from cv_bridge import CvBridge

# Some Tensorflow initialization 
gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
   try:
     # Currently, memory growth needs to be the same across GPUs
     for gpu in gpus:
       tf.config.experimental.set_memory_growth(gpu, True)
     logical_gpus = tf.config.experimental.list_logical_devices('GPU')
     print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")
   except RuntimeError as e:
     # Memory growth must be set before GPUs have been initialized
     print(e)

roi_msg = GetObjectROIRequest()
roi_msg.transform_to_link = "base_link"
roi_msg.voxelize_cloud = False
roi_msg.surface_threshold = 0.015
roi_msg.cluster_distance = 0.05
roi_msg.filter_x = True
roi_msg.min_x = 0.0
roi_msg.max_x = 0.8
roi_msg.filter_y = True
roi_msg.min_y = -0.3
roi_msg.max_y = 0.3
roi_msg.filter_z = False
roi_msg.min_cluster_points = 100
roi_msg.max_cluster_points = 50000
roi_msg.voxelize_cloud = True
roi_msg.leaf_size = 0.005

class ObjectRecognition(object):

  def __init__(self):
    # 
    self.class_names = []
    # Get the parameter from the launch file 
    if rospy.get_param("~load_sim") == True:  
      path = os.path.join(os.environ["HOME"], "data/simple_cnn_rt")
      self.class_names = ["redbox", "greenbox", "bluebox", "yellowbox", "purplebox"]
    else:
      path = os.path.join(os.environ["HOME"], "data/real_cnn_rt/")
      self.class_names = ["graybox", "blackbox", "greenbox", "bluebox", "orangebox"]

    self.image_converter = ImageConverter() # For converting from sensor_msgs/Image to OpenCv Image
    self.image_publisher = rospy.Publisher("/object_image", Image, queue_size=1) # Publisher for publising image
    model = tf.saved_model.load(path, tags=[tag_constants.SERVING]) # Loading the model
    self.predict = model.signatures["serving_default"] 

    IMAGE_WIDTH = 28 # Change according to your specifications
    IMAGE_HEIGHT = 28 # Change according to your specifications

    # The usage of the running a prediction, you can only use 1 image at the time (because of the conversion)
    fake_image = np.zeros((IMAGE_HEIGHT, IMAGE_WIDTH, 3)) # Give it a fake image, just to let it run once (it's slow the first time!)
    output = self.predict(tf.constant(np.asarray([fake_image], dtype=np.float32))) # Call the prediction function
    predictions = output["output"].numpy()[0] # predictions should now be a list of the output values
    output_idx = np.argmax(predictions)
    output_object = self.class_names[output_idx]

    self.cv_bridge = CvBridge()

    # Add the client to get ROI 
    self.roi_client = rospy.ServiceProxy("get_object_roi", GetObjectROI)

    # Add an action server
    self.action_server = actionlib.SimpleActionServer("object_recognition", ObjectRecognitionAction, self.goal_callback, auto_start = False)
    self.action_server.start()

    self.num = 0



  def goal_callback(self, goal_msg):
    try:
      img_msg = rospy.wait_for_message("/camera/color/image_raw", Image, rospy.Duration(1.0))
    except:
      print("No image received")
      self.action_server.set_aborted()
      return 0

    image = self.image_converter.convert_to_opencv(img_msg)
    roi_image = image.copy()
    cnn_image = image.copy()

    try:
      result = self.roi_client(roi_msg)
      roi = result.object_rois[0]
    except:
      self.action_server.set_aborted()
      return 0

    cnn_image = cnn_image[roi.top:roi.bottom,roi.left:roi.right]
    cnn_image = cv2.resize(cnn_image, (28, 28))
    cnn_image = cnn_image / 255.0

    output = self.predict(tf.constant(np.asarray([cnn_image], dtype=np.float32))) # Call the prediction function
    predictions = output["output"].numpy()[0] # predictions should now be a list of the output values
    output_idx = np.argmax(predictions)
    output_object = self.class_names[output_idx]

    cv2.rectangle(roi_image, (roi.left, roi.top), (roi.right, roi.bottom), (36,255,12), 1)
    cv2.putText(roi_image, output_object, (roi.left, roi.top-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36,255,12), 2)

    # Save images to folder
    # roi_img_path = os.path.join(os.environ["HOME"], "img_dump", str(self.num) + ".jpg")
    # cv2.imwrite(roi_img_path, roi_image)
    # self.num += 1

    image_msg = self.image_converter.convert_to_ros(roi_image, "rgb8")
    image_msg.header.frame_id = "camera_link"
    self.image_publisher.publish(image_msg)   

    goal_msg = ObjectRecognitionResult()
    goal_msg.object_name = output_object
    goal_msg.x = int((roi.left+roi.right)/2)
    goal_msg.y = int((roi.top+roi.bottom)/2)
    goal_msg.z = 0

    self.action_server.set_succeeded(goal_msg) 


if __name__ == "__main__":
  rospy.init_node("object_recognition_node") 
  object_recognition = ObjectRecognition()
  rospy.spin()
