from tensorflow.python.compiler.tensorrt import trt_convert as trt
import os

conversion_params = trt.DEFAULT_TRT_CONVERSION_PARAMS
conversion_params = conversion_params._replace(
    max_workspace_size_bytes=(int(1e8)))
conversion_params = conversion_params._replace(precision_mode="FP32")
conversion_params = conversion_params._replace(
    maximum_cached_engines=100)

input_model = os.path.join(os.environ["HOME"], "data/simple_cnn/")
output_model = os.path.join(os.environ["HOME"], "data/simple_cnn_rt/")
converter = trt.TrtGraphConverterV2(input_saved_model_dir=input_model, conversion_params=conversion_params)
converter.convert()
converter.save(output_model)
