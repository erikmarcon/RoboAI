#! /usr/bin/python
import rospy 
import actionlib
from fake_object_recognition.msg import FakeObjectRecognitionAction, FakeObjectRecognitionResult
import random

class FakeObjectRecognitionServer(object):

  def __init__(self):
    self.action_server = actionlib.SimpleActionServer("object_recognition", FakeObjectRecognitionAction, self.goal_callback, auto_start = False)
    self.action_server.start()

  def goal_callback(self, goal_msg):
    sleep_time = 1
    rospy.sleep(sleep_time)

    objects = ["redbox", "greenbox", "bluebox", "yellowbox", "purplebox"]

    goal_msg = FakeObjectRecognitionResult()
    goal_msg.object_name = objects[random.randint(0, len(objects)-1)] # Randomly select an object from the list

    self.action_server.set_succeeded(goal_msg) # We assume it always classifies an object in this case

if __name__ == "__main__":
  rospy.init_node("fake_object_recognition_server")
  fake_object_recognition_server = FakeObjectRecognitionServer()
  rospy.spin()
