from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy

# Import from ObjectRecognitiion Server
import actionlib
from object_recognition.msg import ObjectRecognitionAction, ObjectRecognitionActionGoal, ObjectRecognitionResult

class Recognize(AbstractBehaviour):
    
    def init(self):
        # Create the client
        self.client = actionlib.SimpleActionClient("object_recognition", ObjectRecognitionAction)
        self.client.wait_for_server()

        # Variables
        self.goal = None
        self.object = None

    def update(self):
        if self.goal is None:
            self.goal = ObjectRecognitionActionGoal()
            self.client.send_goal(self.goal)

        if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            self.object = self.client.get_result()
            print "Recognition succeeded"
            self.finish()

        elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
            print "Recognition failed"
            self.fail('Recognition failed')

    
    def reset(self):
        self.state = State.idle
        self.init()