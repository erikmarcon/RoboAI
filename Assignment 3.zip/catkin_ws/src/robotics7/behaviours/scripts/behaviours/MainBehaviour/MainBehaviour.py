from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy


class MainBehaviour(AbstractBehaviour):
    
    def init(self):
        print('Initializing States')
        self.navigate_sub = self.get_behaviour('navigate')
        self.approach_sub = self.get_behaviour('approach')

        self.last_state = None 
        self.approach_succesful = False
        self.done = False
        self.objects = ['Object 1', 'Object 2', 'Object 3']
        self.starting_location = 'Start'
        self.recovery_location = 'Recovery'

    def update(self):
        if self.state != self.last_state:
            print 'Machine in state: ' + str(self.state)
            self.last_state = self.state

        # START
        if self.state == State.start:
            self.set_state(State.navigate)
            self.navigate_sub.set_waypoint(self.objects[0])
            self.navigate_sub.start()

        # NAVIGATE
        elif self.state == State.navigate:
            
            # Navigate receives the name of the Object it should navigate to.
            # There are 3 objects, so it should navigate to all of them until all approaches are succesfull

            if self.navigate_sub.finished():
                self.navigate_sub.reset()

                if self.done:
                    self.state = State.finished
                else:
                    self.set_state(State.approach)
                    self.approach_sub.start()

            elif self.navigate_sub.failed():
                self.navigate_sub.reset()

                # If navigation fails
                # Navigate to starting point, state stays the same
                self.navigate_sub.set_goal_location(self.starting_location)
                self.navigate_sub.start()

        # APPROACH
        elif self.state == State.approach:
           
            if self.approach_sub.finished():
                self.approach_sub.reset()

                # If approach is successful go to the next object location (there exist 3)
                # After the 3rd succesful -> go back to starting position
                # Never approach the same object twice
                self.objects = self.objects[1:]
                self.set_state(State.navigate)

                if len(self.objects) != 0:
                    self.navigate_sub.set_waypoint(self.objects[0])
                else:
                    self.done = True
                    self.navigate_sub.set_waypoint(self.starting_location)

                self.navigate_sub.start()

            elif self.approach_sub.failed():
                self.approach_sub.reset()
                # Approach failed
                # Tries to approach the object, if it fails it should navigate to a RECOVERY WAYPOINT location and try again
                self.navigate_sub.set_goal_location(self.recovery_location)
                self.navigate_sub.start()

        else:
            pass
