from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy


class MainBehaviour(AbstractBehaviour):
    
    def init(self):
        print('Initializing States')
        self.recognize_sub = self.get_behaviour('Recognize')

        self.last_state = None 
        self.object_list = []

    def update(self):
        if self.state != self.last_state:
            print 'Machine in state: ' + str(self.state)
            self.last_state = self.state

        # START
        if self.state == State.start:
            self.set_state(State.recognize)
            self.recognize_sub.start()

        # RECOGNIZE
        elif self.state == State.recognize:            
            # Recognize the object that it's in front of the robot
            # Main Behaviour receives from recognize_sub a list of the label of all objects found AND the coordinates (x,y,z) of their center
            # In our case there's always ONE object!
            if self.recognize_sub.finished():
                # Get the object name and location and print
                self.object_list = self.recognize_sub.object
                print 'Object found:' + str(self.object_list).replace("object_name: ", "")

                # Returns to Start
                self.recognize_sub.reset()
                self.set_state(State.start)

            elif self.recognize_sub.failed():
                self.recognize_sub.reset()
                print 'No object found'
                self.set_state(State.start)

        else:
            pass