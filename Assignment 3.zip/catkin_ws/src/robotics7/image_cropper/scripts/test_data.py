import csv
import cv2
import os

path = os.path.join(os.environ["HOME"], "data/training")
labels = ["redbox", "greenbox", "bluebox", "yellowbox", "purplebox"]

for label in labels:
  data_path = os.path.join(path, label)
  
  with open(os.path.join(data_path, "data.csv")) as f:
    csv_reader = csv.reader(f)

    for row in csv_reader:
      image_path = row[0]
      top = int(row[1])
      bottom = int(row[2])
      left = int(row[3])
      right = int(row[4])

      image = cv2.imread(image_path)
      cv2.rectangle(image, (left, top), (right, bottom), (255, 0, 0))

      cv2.imshow("image", image)
      key = cv2.waitKey(0) & 0xFF # Will wait for any keypress to continue, pressing 'q' will quit the program

      if key == ord("q"):
        exit()
