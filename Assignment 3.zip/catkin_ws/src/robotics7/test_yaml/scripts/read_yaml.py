import rosparam
from rospkg import RosPack
from os.path import join

rospack = RosPack()
path = rospack.get_path("test_yaml") # Name of the package
data = rosparam.load_file(join(path, "scripts/example.yaml"))[0][0]
