import os
import cv2
import numpy as np
import random
import tensorflow as tf
import matplotlib.pyplot as plt

from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.models import Sequential

IMG_HEIGHT, IMG_WIDTH = 28, 28
BATCH_SIZE = 1
EPOCHS = 5

# Load images and labels
path = os.path.join(os.environ["HOME"], "data/training")
class_names = ["redbox", "greenbox", "bluebox", "yellowbox", "purplebox"]

images = []
labels = []

for label in class_names:
    data_path = os.path.join(path, label + "_augmented")

    for filename in os.listdir(data_path):
        image = cv2.imread(os.path.join(data_path, filename))
        images.append(image)
        labels.append(label)

# Pre-process images
for idx in range(len(images)):
    images[idx] = cv2.resize(images[idx], (28, 28))

images = np.asarray(images)
X = images / 255.0

# One-hot encode labels
y = np.zeros((images.shape[0], len(class_names)), dtype=np.int8)

for idx in range(y.shape[0]):
    label_idx = class_names.index(labels[idx])
    y[idx, label_idx] = 1

# Shuffle and split data
idx = np.random.permutation(len(X))
X, y = X[idx], y[idx]

split = int(0.8 * len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]

# Build CNN

num_classes = len(class_names)

model = Sequential([
    layers.Conv2D(16, 3, padding='same', activation='relu', input_shape=(IMG_HEIGHT, IMG_WIDTH, 3)),
    layers.MaxPooling2D(),
    layers.Conv2D(32, 3, padding='same', activation='relu'),
    layers.MaxPooling2D(),
    layers.Conv2D(64, 3, padding='same', activation='relu'),
    layers.MaxPooling2D(),
    layers.Flatten(),
    layers.Dense(128, activation='relu'),
    layers.Dense(num_classes, activation="softmax", name="output")
])

model.compile(
    optimizer='adam',
    loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),
    metrics=['accuracy'],
    )

# train CNN
history = model.fit(
    x=X_train,
    y=y_train,
    #batch_size=BATCH_SIZE,
    epochs=EPOCHS,
)

# evaluate CNN
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=2)

print(f"Test loss: {test_loss}")
print(f"Test accuracy: {test_acc}")

# save model
model.save("sim_model")
