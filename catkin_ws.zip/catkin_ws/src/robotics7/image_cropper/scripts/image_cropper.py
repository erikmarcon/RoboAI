import rospy
from sensor_msgs.msg import Image
import cv2
import os
import sys 
import csv
from point_cloud_functions.srv import GetObjectROI, GetObjectROIRequest
from cv_bridge import CvBridge
import numpy as np
import time 

### Params
topic = "/camera/color/image_raw" 
path = os.path.join(os.environ["HOME"], "data/training")
count = 0
data = []

if len(sys.argv) != 2:
  print "Provide object name"
  exit()

object_name = sys.argv[1]
object_path = os.path.join(path, object_name)

if not os.path.exists(path):
  os.mkdir(path)

if not os.path.exists(object_path):
  os.mkdir(object_path)


def image_callback(event):
  global count, data
  img_msg = rospy.wait_for_message(topic, Image)
  image = cv_bridge.imgmsg_to_cv2(img_msg, "bgr8")
  roi_image = image.copy()

  try:
    result = roi_client(roi_msg)
  except:
    return

  if len(result.object_rois) != 1:
    return
  
  roi = result.object_rois[0]
  cv2.rectangle(roi_image, (roi.left, roi.top), (roi.right, roi.bottom), (255, 0, 0))

  cv2.imshow("image_roi", roi_image)
  key = cv2.waitKey(1) & 0xFF

  if key == ord("q"):
    print "Saving data:", len(data)
    with open(os.path.join(object_path, "data.csv"),'wb') as f:
      writer = csv.writer(f)
      writer.writerows(data)

    rospy.signal_shutdown("done")
    return
  
  if key == ord(" "):
    save_path = os.path.join(object_path, str(count)+".jpg")
    count += 1
    cv2.imwrite(save_path, image)
    data.append([save_path, roi.top, roi.bottom, roi.left, roi.right])
    print count

rospy.init_node("image_cropper")
cv_bridge = CvBridge()
roi_client = rospy.ServiceProxy("get_object_roi", GetObjectROI)

roi_msg = GetObjectROIRequest()
roi_msg.transform_to_link = "base_link"
roi_msg.voxelize_cloud = False
roi_msg.surface_threshold = 0.015
roi_msg.cluster_distance = 0.05
roi_msg.filter_x = True
roi_msg.min_x = 0.0
roi_msg.max_x = 0.8
roi_msg.filter_y = True
roi_msg.min_y = -0.3
roi_msg.max_y = 0.3
roi_msg.filter_z = False
roi_msg.min_cluster_points = 100
roi_msg.max_cluster_points = 50000
roi_msg.voxelize_cloud = True
roi_msg.leaf_size = 0.005

timer = rospy.Timer(rospy.Duration(1.0/6.0), image_callback)
rospy.spin()
