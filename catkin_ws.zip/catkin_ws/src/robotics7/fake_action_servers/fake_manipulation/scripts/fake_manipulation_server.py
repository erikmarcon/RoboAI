#! /usr/bin/python
import rospy 
import actionlib 
import random
from fake_manipulation.msg import FakeGraspAction, FakeGraspResult, FakeDropAction, FakeDropResult

class FakeManipulationServer(object):

  def __init__(self):
    self.grasp_server = actionlib.SimpleActionServer("/grasp", FakeGraspAction, self.grasp_callback, auto_start = False)
    self.drop_server = actionlib.SimpleActionServer("/drop", FakeDropAction, self.drop_callback, auto_start = False)

    self.grasp_server.start()
    self.drop_server.start()

  def grasp_callback(self, goal_msg):
    sleep_time = random.randint(2, 5) # Sleep for 2 to 5 seconds 
    rospy.sleep(sleep_time) # Sleep (pretending the arm is moving)

    success_probability = 0.8 # Decrease the probability to increase failure rate
    success = True if random.random() <= success_probability else False # Grasp succeeded or not 

    if success:
      self.grasp_server.set_succeeded() # Set the action server to success (you can assume the object was grasped)
    else:
      self.grasp_server.set_aborted() # Set the action server to aborted (something went wrong)

  def drop_callback(self, goal_msg):
      sleep_time = random.randint(2, 5) # Sleep for 2 to 5 seconds 
      rospy.sleep(sleep_time)

      success_probability = 0.9 # Decrease the probability to increase failure rate
      success = True if random.random() <= success_probability else False # The drop succeeded or not

      if success:
        self.drop_server.set_succeeded() # Set the action server to success (you can assume the arm dropped the object)
      else:
        self.drop_server.set_aborted() # Set the action server to aborted (something went wrong)
    
if __name__ == "__main__":
  rospy.init_node("manipulation_server")
  fake_manipulation_server = FakeManipulationServer()
  rospy.spin()



