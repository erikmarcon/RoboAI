#! /usr/bin/python
import rospy 
import actionlib
from fake_navigation.msg import FakeNavigationAction
import random

class FakeNavigationServer(object):

  def __init__(self):
    self.action_server = actionlib.SimpleActionServer("/navigate", FakeNavigationAction, self.goal_callback, auto_start = False)
    self.action_server.start()
  
  def goal_callback(self, goal_msg):
    sleep_time = random.randint(2, 5) # Sleep for 2 to 5 seconds 
    rospy.sleep(sleep_time) # Sleep (pretending the robot is driving)

    success_probability = 0.9 # Decrease the probability to increase failure rate
    success = True if random.random() <= success_probability else False # Navigation will succeed most of the time, this can simulate the robot getting stuck.

    if success:
      self.action_server.set_succeeded() # Set the action server to success (robot has arrived at its goal)
    else:
      self.action_server.set_aborted() # Set the action server to aborted (pretends the robot got stuck)

if __name__ == "__main__":
  rospy.init_node("fake_navigation_server")
  fake_navigation_server = FakeNavigationServer()
  rospy.spin()