#! /usr/bin/python
import rospy
import actionlib
from approach_objects.msg import ApproachObjectAction, ApproachObjectGoal, ApproachObjectResult
import random

class FakeApproachServer(object):

  def __init__(self):
    self.action_server = actionlib.SimpleActionServer("/approach_objects", ApproachObjectAction, self.goal_callback, auto_start = False)
    self.action_server.start()

  def goal_callback(self, goal_msg):
    sleep_time = random.randint(1, 3) # Sleep for 1 to 3 seconds 
    rospy.sleep(sleep_time) # Sleep (pretending the robot is approaching the object)

    success_probability = 0.7 # Decrease the probability to increase failure rate
    success = True if random.random() <= success_probability else False # Approach will succeed if it can find an object, if no object is found it will fail with error code NO_OBJECT_FOUNDS

    result = ApproachObjectResult()

    if success:
      result.error_code = ApproachObjectResult.SUCCEEDED # Set the error code to SUCCEEDED
      self.action_server.set_succeeded(result) # Set the action server to success (robot has approached the object)
    else:
      result.error_code = ApproachObjectResult.NO_OBJECTS_FOUND # Set the error code to NO OBJECT FOUND
      self.action_server.set_succeeded(result) # Set the action server to aborted (robot could not find an object to approach)

if __name__ == "__main__":
  rospy.init_node("fake_approach_server")
  fake_approach_server = FakeApproachServer()
  rospy.spin()
