from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy


class MainBehaviour(AbstractBehaviour):
    
    def init(self):
        print('Initializing States')
        self.receive_sub = self.get_behaviour('receive_order')
        self.navigate_sub = self.get_behaviour('navigate')
        self.approach_sub = self.get_behaviour('approach')
        self.grasp_sub = self.get_behaviour('grasp')
        self.drop_sub = self.get_behaviour('drop')
        self.recognize_sub = self.get_behaviour('recognize')

    def update(self):
        print 'Machine in state: ' + str(self.state)

        if self.state == State.start:
            self.set_state(State.receive_order)
            self.receive_sub.start()

        elif self.state == State.receive_order:

            if self.receive_sub.finished():
                self.receive_sub.reset()
                # Do what? -> Go to which state?
                self.set_state(State.navigate)
                self.navigate_sub.start()
            elif self.receive_sub.failed():
                self.receive_sub.reset()
                # What to do if it fails???

        elif self.state == State.navigate:
            if self.navigate_sub.finished():
                self.navigate_sub.reset()
                # Do what? -> Go to which state?
                self.set_state(State.approach)
                self.approach_sub.start()
            elif self.navigate_sub.failed():
                self.navigate_sub.reset()
                # What to do if it fails???

        elif self.state == State.approach:
            
            if self.approach_sub.finished():
                self.approach_sub.reset()
                # Do what? -> Go to which state?
                self.set_state(State.recognize)
                self.recognize_sub.start()
            elif self.approach_sub.failed():
                self.approach_sub.reset()
                # What to do if it fails???

        elif self.state == State.grasp:
            
            if self.grasp_sub.finished():
                self.grasp_sub.reset()
                # Do what? -> Go to which state?
                self.set_state(State.navigate)
                self.navigate_sub.start()
            elif self.grasp_sub.failed():
                self.grasp_sub.reset()
                # What to do if it fails???

        elif self.state == State.drop:
            
            if self.drop_sub.finished():
                self.drop_sub.reset()
                # Do what? -> Go to which state?
                # self.set_state(State.NEWSTATE)
                # self.NEWSTATE.start()
            elif self.drop_sub.failed():
                self.drop_sub.reset()
                # What to do if it fails???

        elif self.state == State.recognize:
            
            if self.recognize_sub.finished():
                self.recognize_sub.reset()
                # Do what? -> Go to which state?
                self.set_state(State.grasp)
                self.grasp_sub.start()
            elif self.recognize_sub.failed():
                self.recognize_sub.reset()
                # What to do if it fails???

        else:
            pass

