from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy


class recognize(AbstractBehaviour):
    
    def init(self):
        pass

    def update(self):
        print "Finished recognizing"
        self.finish()
    
    def reset(self):
        self.state = State.idle
        self.init()