from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy
from order.msg import Order

class receive_order(AbstractBehaviour):

    def init(self):
        pass

    def update(self):
        order_msg = rospy.wait_for_message("/order", Order, 5) # Wait for 0.5 seconds to receive something
        print order_msg.objects # Print the objects
        self.finish()
 
    def reset(self):
        self.state = State.idle
        self.init()