from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy
from order.msg import Order

class receive_order(AbstractBehaviour):

    def init(self):
        pass

    def update(self):
        rospy.Subscriber("/order", Order, self.callback)
 
    def reset(self):
        self.state = State.idle
        self.init()

    def callback(self, data):
        print "Callback"
        self.finish()
