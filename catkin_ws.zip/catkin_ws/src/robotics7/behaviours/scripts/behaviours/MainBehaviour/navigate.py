from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import actionlib
import rospy
from fake_navigation.msg import FakeNavigationAction, FakeNavigationActionGoal
import time


class navigate(AbstractBehaviour):
    
    def init(self):
        self.client = actionlib.SimpleActionClient("/navigate", FakeNavigationAction)
        self.client.wait_for_server()


    def update(self):
        self.goal = FakeNavigationActionGoal()
        self.goal.goal = "kitchen"
        self.client.send_goal(self.goal)

        while True:
            time.sleep(1)

            if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
                self.finish()
                break

            elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
                print "ERROR"
                break
            
            else:
                print self.client.get_state()
            

        
    
    def reset(self):
        self.state = State.idle
        self.init()