from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import actionlib
import rospy
from fake_navigation.msg import FakeNavigationAction, FakeNavigationGoal


class navigate(AbstractBehaviour):
    
    def init(self):
        # self.client = actionlib.SimpleActionClient("/navigate", FakeNavigationAction)
        # self.client.wait_for_server()
        # self.goal = FakeNavigationGoal()
        # self.goal.goal = "kitchen"
        # self.client.send_goal(self.goal)
        pass

    def update(self):
        print "Finished navigating"
        self.finish()
    
    def reset(self):
        self.state = State.idle
        self.init()