from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy


class grasp(AbstractBehaviour):
    
    def init(self):
        pass

    def update(self):
        print "Finished grasping"
        self.finish()
    
    def reset(self):
        self.state = State.idle
        self.init()