#!/usr/bin/env python3
import rospy 
import os 
from point_cloud_functions.srv import GetObjectROI, GetObjectROIRequest
from image_converter import ImageConverter
import cv2
from sensor_msgs.msg import Image
import numpy as np
import tensorflow as tf 
from tensorflow.python.saved_model import tag_constants

# Some Tensorflow initialization 
gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
   try:
     # Currently, memory growth needs to be the same across GPUs
     for gpu in gpus:
       tf.config.experimental.set_memory_growth(gpu, True)
     logical_gpus = tf.config.experimental.list_logical_devices('GPU')
     print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")
   except RuntimeError as e:
     # Memory growth must be set before GPUs have been initialized
     print(e)

class ObjectRecognition(object):

  def __init__(self):
    # Get the parameter from the launch file 
    if rospy.get_param("~load_sim") == True:  
      path = os.path.join(os.environ["HOME"], "data/simple_cnn_rt") # @TODO: Check if the path is correct for loading the sim model
    else:
      path = None # @TODO: Change path 

    self.image_converter = ImageConverter() # For converting from sensor_msgs/Image to OpenCv Image
    self.image_publisher = rospy.Publisher("/object_image", Image, queue_size=1) # Publisher for publising image
    model = tf.saved_model.load(path, tags=[tag_constants.SERVING]) # Loading the model
    self.predict = model.signatures["serving_default"] 

    IMAGE_WIDTH = 28 # @TODO: Change according to your specifications
    IMAGE_HEIGHT = 28 # @TODO: Change according to your specifications

    # The usage of the running a prediction, you can only use 1 image at the time (because of the conversion)
    fake_image = np.zeros((IMAGE_HEIGHT, IMAGE_WIDTH, 3)) # Give it a fake image, just to let it run once (it's slow the first time!)
    output = self.predict(tf.constant(np.asarray([fake_image], dtype=np.float32))) # Call the prediction function
    predictions = output["output"].numpy()[0] # predictions should now be a list of the output values  

    # @TODO: Add the client to get ROI 
    # @TODO: Add an action server


if __name__ == "__main__":
  rospy.init_node("object_recognition_node") 
  object_recognition = ObjectRecognition()
  rospy.spin()
