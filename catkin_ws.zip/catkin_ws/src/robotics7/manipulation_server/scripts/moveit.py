import rospy
import moveit_commander
from moveit_commander import MoveGroupCommander, PlanningSceneInterface
from moveit_msgs.msg import MoveItErrorCodes, Grasp, GripperTranslation
from tf.transformations import quaternion_from_euler, euler_from_quaternion
from std_srvs.srv import Empty
from geometry_msgs.msg import PoseStamped, Pose
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
import sys
import tf
import math
import numpy as np

class MoveIt(object):

  def __init__(self):
    moveit_commander.roscpp_initialize(sys.argv)
    self.scene = PlanningSceneInterface()
    self.arm = MoveGroupCommander("arm")
    self.gripper = MoveGroupCommander("gripper")

    self.arm.set_planner_id("RRTConnect") # Should already be default 
    print "End effector link used:", self.arm.get_end_effector_link()

    self.arm.allow_replanning(True)
    self.arm.set_planning_time(5)
    self.arm.set_num_planning_attempts(2)

    self.transformer = tf.TransformListener()
    rospy.sleep(2) # Allow some time for initialization of MoveIt
    
    self.end_effector_link = self.arm.get_end_effector_link()

  def __del__(self):
    moveit_commander.roscpp_shutdown()
    moveit_commander.os._exit(0)

  def add_floor(self):
    self.add_collision_object(0.5, 0, -0.005, 0, box_size = [1.0, 1.0, 0.01], name = "floor", frame_id = "base_footprint", scaler = 1.0)

  def clear_collision_models(self):
    self.scene.remove_world_object()
    rospy.sleep(0.5)

  def remove_obstacle_from_gripper(self):
    self.scene.remove_attached_object(self.end_effector_link)

  def add_collision_object(self, x, y, z, rotation, box_size, name, frame_id = "arm_link0", scaler = 1.1):
    q = quaternion_from_euler(math.pi, 0.0, rotation)
    object_pose = PoseStamped()
    object_pose.header.frame_id = frame_id
    object_pose.pose.position.x = x
    object_pose.pose.position.y = y
    object_pose.pose.position.z = z
    object_pose.pose.orientation.x = q[0]
    object_pose.pose.orientation.y = q[1]
    object_pose.pose.orientation.z = q[2]
    object_pose.pose.orientation.w = q[3]

    # Add the box to the scene
    box_size[0] *= scaler
    box_size[1] *= scaler
    box_size[2] *= scaler
    self.scene.add_box(name, object_pose, box_size)
    
  def _open_gripper(self):
    joint_trajectory = JointTrajectory()
    joint_trajectory.header.stamp = rospy.get_rostime()

    joint_trajectory.joint_names = ["left_finger_joint", "right_finger_joint"]

    joint_trajectory_point = JointTrajectoryPoint()
    joint_trajectory_point.positions = [1.05, 1.05]
    joint_trajectory_point.time_from_start = rospy.Duration(5.0)
  
    joint_trajectory.points.append(joint_trajectory_point)
    return joint_trajectory

  def _close_gripper(self, width = None):
    joint_trajectory = JointTrajectory()
    joint_trajectory.header.stamp = rospy.get_rostime()

    joint_trajectory.joint_names = ["left_finger_joint", "right_finger_joint"]

    joint_trajectory_point = JointTrajectoryPoint()
    
    if not width == None:
        finger_distance_from_center = 0.007
        w = (width / 2) - finger_distance_from_center
        if w > 0:
          angle = math.asin(w / 0.075) # 0.075 is finger length
          joint_trajectory_point.positions = [angle, angle]
        else:
          joint_trajectory_point.positions = [0, 0]
    else:
        joint_trajectory_point.positions = [0.00, 0.00]
        
    joint_trajectory_point.time_from_start = rospy.Duration(5.0)
    joint_trajectory.points.append(joint_trajectory_point)
    return joint_trajectory
    
  def _make_gripper_translation_approach(self, min_distance = 0.03, desired_distance = 0.05):
    gripper_translation = GripperTranslation()
    gripper_translation.direction.vector.x = 0.0
    gripper_translation.direction.vector.y = 0.0
    gripper_translation.direction.vector.z = 1.0

    gripper_translation.direction.header.frame_id = self.end_effector_link
    gripper_translation.min_distance = min_distance
    gripper_translation.desired_distance = desired_distance

    return gripper_translation

  def _make_gripper_translation_retreat(self, min_distance = 0.03, desired_distance = 0.05):
    gripper_translation = GripperTranslation()
    gripper_translation.direction.vector.z = 1.0
    gripper_translation.direction.header.frame_id = "arm_link0"
    gripper_translation.min_distance = min_distance
    gripper_translation.desired_distance = desired_distance
    
    return gripper_translation

  def _create_grasps(self, x, y, z, rotation, z_max, width = None):
    grasps = [] # List that will return the different grasp messages
    q = quaternion_from_euler(0, math.pi, rotation) # Sets the rotations correctly and converts to quaternion

    # create a variable, assign it the Grasp() message 
    # for the pre grasp posture use the self._open_gripper() function
    # for the grasp posture use the self._close_gripper(width) function
    # the variable should have a grasp_pose.pose.position with x, y, and z variable you need to fill in, z needs to be max object height - 0.02m.  
    # the variable should have a grasp_pose.pose.orientation (in quaternion), with a x, y, z, w, which refers to the q variable [0], [1], [2], [3]
    # set the grasp_pose.header.frame_id to "arm_link0" (this is the planning frame of reference)
    # set the pre_grasp_approach to self._make_gripper_translation_approach()
    # set the post_grasp_retreat to self._make_gripper_translation_retreat()
    # append the grasp to the list of grasps (which will be returned)

    print "Nr of grasps created:", len(grasps)
    return grasps

  def grasp(self, x, y, z, rotation, z_max, object_name, width=None):
    grasps = self._create_grasps(x, y, z, rotation, z_max, width=width)

    if len(grasps) == 0:
      print "Can not create grasps"
      return False
    
    result = self.arm.pick(object_name, grasps)

    if result == MoveItErrorCodes.SUCCESS:
      print "Success"
      return True
    else:
      print "Failed"
      return False

  def open_fingers(self):
    self.gripper.set_joint_value_target([1.0, 1.0])
    self.gripper.go(wait=True)
    rospy.sleep(2.0)

  def close_fingers(self):
    self.gripper.set_joint_value_target([0, 0])
    self.gripper.go(wait=True)
    rospy.sleep(2.0)

  def move_to(self, x, y, z, roll, pitch, yaw):
      q = quaternion_from_euler(roll, pitch, yaw)
      
      pose = PoseStamped()
      pose.header.frame_id = "arm_link0"
      pose.pose.position.x = x
      pose.pose.position.y = y
      pose.pose.position.z = z
      pose.pose.orientation.x = q[0]
      pose.pose.orientation.y = q[1]
      pose.pose.orientation.z = q[2]
      pose.pose.orientation.w = q[3]

      self.arm.set_pose_target(pose, self.end_effector_link)
      plan = self.arm.plan()

      result = self.arm.go(wait=True)
      self.arm.stop()
      self.arm.clear_pose_targets()
      return result


  def move_joints(self, joint_position):
    self.arm.set_joint_value_target(joint_position)
    plan = self.arm.plan()
    return self.arm.go(wait=True)

  def move_to_rest(self):
    rest_position = {}
    rest_position["arm_joint1"] = 2.3911
    rest_position["arm_joint2"] = 0.39634051462172604
    rest_position["arm_joint3"] = 1.9195986796783266
    rest_position["arm_joint4"] = 2.319346282794408
    rest_position["arm_joint5"] = 0.9407630289365638
    rest_position["arm_joint6"] = 0.588648436002

    return self.move_joints(rest_position)

  def print_position(self):
    pose = self.arm.get_current_pose()
    self.transformer.waitForTransform(self.end_effector_link, "arm_link0", rospy.Time.now(), rospy.Duration(5.0))
    eef_pose = self.transformer.transformPose("arm_link0", pose)

    orientation = eef_pose.pose.orientation
    orientation = [orientation.x, orientation.y, orientation.z, orientation.w]

    euler = euler_from_quaternion(orientation)

    print "x:", eef_pose.pose.position.x
    print "y:", eef_pose.pose.position.y
    print "z:", eef_pose.pose.position.z
    print "euler: (roll, pitch, yaw)", euler
