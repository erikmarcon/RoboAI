
"use strict";

let FakeDropActionResult = require('./FakeDropActionResult.js');
let FakeGraspFeedback = require('./FakeGraspFeedback.js');
let FakeGraspActionFeedback = require('./FakeGraspActionFeedback.js');
let FakeDropActionFeedback = require('./FakeDropActionFeedback.js');
let FakeDropAction = require('./FakeDropAction.js');
let FakeGraspActionResult = require('./FakeGraspActionResult.js');
let FakeGraspActionGoal = require('./FakeGraspActionGoal.js');
let FakeDropResult = require('./FakeDropResult.js');
let FakeDropGoal = require('./FakeDropGoal.js');
let FakeGraspResult = require('./FakeGraspResult.js');
let FakeGraspGoal = require('./FakeGraspGoal.js');
let FakeDropFeedback = require('./FakeDropFeedback.js');
let FakeGraspAction = require('./FakeGraspAction.js');
let FakeDropActionGoal = require('./FakeDropActionGoal.js');

module.exports = {
  FakeDropActionResult: FakeDropActionResult,
  FakeGraspFeedback: FakeGraspFeedback,
  FakeGraspActionFeedback: FakeGraspActionFeedback,
  FakeDropActionFeedback: FakeDropActionFeedback,
  FakeDropAction: FakeDropAction,
  FakeGraspActionResult: FakeGraspActionResult,
  FakeGraspActionGoal: FakeGraspActionGoal,
  FakeDropResult: FakeDropResult,
  FakeDropGoal: FakeDropGoal,
  FakeGraspResult: FakeGraspResult,
  FakeGraspGoal: FakeGraspGoal,
  FakeDropFeedback: FakeDropFeedback,
  FakeGraspAction: FakeGraspAction,
  FakeDropActionGoal: FakeDropActionGoal,
};
