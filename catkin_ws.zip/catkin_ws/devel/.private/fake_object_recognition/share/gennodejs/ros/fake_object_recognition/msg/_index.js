
"use strict";

let FakeObjectRecognitionActionFeedback = require('./FakeObjectRecognitionActionFeedback.js');
let FakeObjectRecognitionActionGoal = require('./FakeObjectRecognitionActionGoal.js');
let FakeObjectRecognitionAction = require('./FakeObjectRecognitionAction.js');
let FakeObjectRecognitionResult = require('./FakeObjectRecognitionResult.js');
let FakeObjectRecognitionFeedback = require('./FakeObjectRecognitionFeedback.js');
let FakeObjectRecognitionGoal = require('./FakeObjectRecognitionGoal.js');
let FakeObjectRecognitionActionResult = require('./FakeObjectRecognitionActionResult.js');

module.exports = {
  FakeObjectRecognitionActionFeedback: FakeObjectRecognitionActionFeedback,
  FakeObjectRecognitionActionGoal: FakeObjectRecognitionActionGoal,
  FakeObjectRecognitionAction: FakeObjectRecognitionAction,
  FakeObjectRecognitionResult: FakeObjectRecognitionResult,
  FakeObjectRecognitionFeedback: FakeObjectRecognitionFeedback,
  FakeObjectRecognitionGoal: FakeObjectRecognitionGoal,
  FakeObjectRecognitionActionResult: FakeObjectRecognitionActionResult,
};
