// Auto-generated. Do not edit!

// (in-package bounding_box_server.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let BoundingBox = require('../msg/BoundingBox.js');

//-----------------------------------------------------------

class GetBoundingBoxRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.transform_to = null;
      this.surface_threshold = null;
      this.cluster_threshold = null;
      this.min_x = null;
      this.max_x = null;
      this.z_top_range = null;
    }
    else {
      if (initObj.hasOwnProperty('transform_to')) {
        this.transform_to = initObj.transform_to
      }
      else {
        this.transform_to = '';
      }
      if (initObj.hasOwnProperty('surface_threshold')) {
        this.surface_threshold = initObj.surface_threshold
      }
      else {
        this.surface_threshold = 0.0;
      }
      if (initObj.hasOwnProperty('cluster_threshold')) {
        this.cluster_threshold = initObj.cluster_threshold
      }
      else {
        this.cluster_threshold = 0.0;
      }
      if (initObj.hasOwnProperty('min_x')) {
        this.min_x = initObj.min_x
      }
      else {
        this.min_x = 0.0;
      }
      if (initObj.hasOwnProperty('max_x')) {
        this.max_x = initObj.max_x
      }
      else {
        this.max_x = 0.0;
      }
      if (initObj.hasOwnProperty('z_top_range')) {
        this.z_top_range = initObj.z_top_range
      }
      else {
        this.z_top_range = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetBoundingBoxRequest
    // Serialize message field [transform_to]
    bufferOffset = _serializer.string(obj.transform_to, buffer, bufferOffset);
    // Serialize message field [surface_threshold]
    bufferOffset = _serializer.float32(obj.surface_threshold, buffer, bufferOffset);
    // Serialize message field [cluster_threshold]
    bufferOffset = _serializer.float32(obj.cluster_threshold, buffer, bufferOffset);
    // Serialize message field [min_x]
    bufferOffset = _serializer.float32(obj.min_x, buffer, bufferOffset);
    // Serialize message field [max_x]
    bufferOffset = _serializer.float32(obj.max_x, buffer, bufferOffset);
    // Serialize message field [z_top_range]
    bufferOffset = _serializer.float32(obj.z_top_range, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetBoundingBoxRequest
    let len;
    let data = new GetBoundingBoxRequest(null);
    // Deserialize message field [transform_to]
    data.transform_to = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [surface_threshold]
    data.surface_threshold = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cluster_threshold]
    data.cluster_threshold = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [min_x]
    data.min_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [max_x]
    data.max_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [z_top_range]
    data.z_top_range = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.transform_to.length;
    return length + 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'bounding_box_server/GetBoundingBoxRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3806518235c22aa7de380a20bb4e166c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string transform_to
    float32 surface_threshold
    float32 cluster_threshold
    float32 min_x 
    float32 max_x 
    float32 z_top_range
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetBoundingBoxRequest(null);
    if (msg.transform_to !== undefined) {
      resolved.transform_to = msg.transform_to;
    }
    else {
      resolved.transform_to = ''
    }

    if (msg.surface_threshold !== undefined) {
      resolved.surface_threshold = msg.surface_threshold;
    }
    else {
      resolved.surface_threshold = 0.0
    }

    if (msg.cluster_threshold !== undefined) {
      resolved.cluster_threshold = msg.cluster_threshold;
    }
    else {
      resolved.cluster_threshold = 0.0
    }

    if (msg.min_x !== undefined) {
      resolved.min_x = msg.min_x;
    }
    else {
      resolved.min_x = 0.0
    }

    if (msg.max_x !== undefined) {
      resolved.max_x = msg.max_x;
    }
    else {
      resolved.max_x = 0.0
    }

    if (msg.z_top_range !== undefined) {
      resolved.z_top_range = msg.z_top_range;
    }
    else {
      resolved.z_top_range = 0.0
    }

    return resolved;
    }
};

class GetBoundingBoxResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.bounding_boxes = null;
    }
    else {
      if (initObj.hasOwnProperty('bounding_boxes')) {
        this.bounding_boxes = initObj.bounding_boxes
      }
      else {
        this.bounding_boxes = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetBoundingBoxResponse
    // Serialize message field [bounding_boxes]
    // Serialize the length for message field [bounding_boxes]
    bufferOffset = _serializer.uint32(obj.bounding_boxes.length, buffer, bufferOffset);
    obj.bounding_boxes.forEach((val) => {
      bufferOffset = BoundingBox.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetBoundingBoxResponse
    let len;
    let data = new GetBoundingBoxResponse(null);
    // Deserialize message field [bounding_boxes]
    // Deserialize array length for message field [bounding_boxes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.bounding_boxes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.bounding_boxes[i] = BoundingBox.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 28 * object.bounding_boxes.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'bounding_box_server/GetBoundingBoxResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9bb1d789f1adc66cc6145ead9caa3cee';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bounding_box_server/BoundingBox[] bounding_boxes
    
    
    ================================================================================
    MSG: bounding_box_server/BoundingBox
    float32 x
    float32 y
    float32 z
    float32 length
    float32 width
    float32 height
    float32 yaw
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetBoundingBoxResponse(null);
    if (msg.bounding_boxes !== undefined) {
      resolved.bounding_boxes = new Array(msg.bounding_boxes.length);
      for (let i = 0; i < resolved.bounding_boxes.length; ++i) {
        resolved.bounding_boxes[i] = BoundingBox.Resolve(msg.bounding_boxes[i]);
      }
    }
    else {
      resolved.bounding_boxes = []
    }

    return resolved;
    }
};

module.exports = {
  Request: GetBoundingBoxRequest,
  Response: GetBoundingBoxResponse,
  md5sum() { return '812d0f2fe99eb0768989d1d2e1978422'; },
  datatype() { return 'bounding_box_server/GetBoundingBox'; }
};
