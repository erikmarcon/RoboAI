
"use strict";

let FakeNavigationActionGoal = require('./FakeNavigationActionGoal.js');
let FakeNavigationResult = require('./FakeNavigationResult.js');
let FakeNavigationFeedback = require('./FakeNavigationFeedback.js');
let FakeNavigationGoal = require('./FakeNavigationGoal.js');
let FakeNavigationActionFeedback = require('./FakeNavigationActionFeedback.js');
let FakeNavigationActionResult = require('./FakeNavigationActionResult.js');
let FakeNavigationAction = require('./FakeNavigationAction.js');

module.exports = {
  FakeNavigationActionGoal: FakeNavigationActionGoal,
  FakeNavigationResult: FakeNavigationResult,
  FakeNavigationFeedback: FakeNavigationFeedback,
  FakeNavigationGoal: FakeNavigationGoal,
  FakeNavigationActionFeedback: FakeNavigationActionFeedback,
  FakeNavigationActionResult: FakeNavigationActionResult,
  FakeNavigationAction: FakeNavigationAction,
};
