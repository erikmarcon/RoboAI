from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy

# Imports to load .yaml files
import rosparam
from rospkg import RosPack
from os.path import join

# Import from MoveBase Server
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal


class navigate(AbstractBehaviour):
    
    def init(self):
        # Load files
        rospack = RosPack()
        self.path = rospack.get_path("behaviours")
        self.data = rosparam.load_file(join(self.path, "scripts/behaviours/MainBehaviour/Waypoints.yaml"))[0][0]

        # Create the client
        self.client = actionlib.SimpleActionClient("move_base", MoveBaseAction)
        self.client.wait_for_server()

        # Variables
        self.goal = None
        self.position = [0.0, 0.0, 0.0]
        self.orientation = [0.0, 0.0, 0.0, 1.0]

    def update(self):
        if self.goal is None:
            self.goal = MoveBaseGoal()
            self.goal.target_pose.header.frame_id = 'map'
            self.goal.target_pose.header.stamp = rospy.Time.now()

            # Navigate to position
            self.goal.target_pose.pose.position.x,  \
            self.goal.target_pose.pose.position.y,  \
            self.goal.target_pose.pose.position.z   \
                = self.position

            # Orientation of the navigation
            self.goal.target_pose.pose.orientation.x,   \
            self.goal.target_pose.pose.orientation.y,   \
            self.goal.target_pose.pose.orientation.z,   \
            self.goal.target_pose.pose.orientation.w    \
                = self.orientation

            # Sends the coordinate informations to the MoveBase action server
            self.client.send_goal(self.goal)

        elif self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            print 'Navigation Finished'
            self.finish()

        elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
            self.fail('Navigation Failed')

    def set_waypoint(self, waypoint):
        self.position = self.data[waypoint][0]['pos']
        self.orientation =  self.data[waypoint][1]['ori']
    
    def reset(self):
        self.state = State.idle
        self.init()