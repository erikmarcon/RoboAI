from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import actionlib
from approach_objects.msg import ApproachObjectAction, ApproachObjectGoal

import rospy


class approach(AbstractBehaviour):
    
    def init(self):
        self.client = actionlib.SimpleActionClient("/approach_objects", ApproachObjectAction)
        self.client.wait_for_server()
        self.goal = None

    def update(self):
        if self.goal is None:
            self.goal = ApproachObjectGoal()
            self.client.send_goal(self.goal)

        if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            self.finish()

        elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
            self.fail('Approach Failed')
    
    def reset(self):
        self.state = State.idle
        self.init()