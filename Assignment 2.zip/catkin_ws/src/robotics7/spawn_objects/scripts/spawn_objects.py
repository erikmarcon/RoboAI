#!/usr/bin/env python
import rospy 
from gazebo_msgs.srv import SpawnModel, DeleteModel, GetModelState
from geometry_msgs.msg import *
import tf
import rospkg
from math import pi
from random import shuffle, uniform, randint

class ObjectManager(object):
    
    def __init__(self): 
        self.objects = ["box0", "box1", "box2", "box3", "box4"]

        rospy.wait_for_service("/gazebo/spawn_sdf_model")

        self.spawn_model = rospy.ServiceProxy("/gazebo/spawn_sdf_model", SpawnModel)
        self.delete_model = rospy.ServiceProxy("/gazebo/delete_model", DeleteModel)
        self.get_model_state = rospy.ServiceProxy("/gazebo/get_model_state", GetModelState)
        
        self.rospack = rospkg.RosPack()

        rospy.on_shutdown(self.shutdown)
    
        place1 = [2.0, 3.0]
        place2 = [-4.0, 0.5]
        place3 = [-1.0, -5.0]

        places = [place1, place2, place3]
        shuffle(places)
        shuffle(self.objects)
        self.spawned_objects = self.objects[0:3]

        self.spawn_object(self.spawned_objects[0], places[0][0], places[0][1], 0.1, uniform(0, pi))
        self.spawn_object(self.spawned_objects[1], places[1][0], places[1][1], 0.1, uniform(0, pi))
        self.spawn_object(self.spawned_objects[2], places[2][0], places[2][1], 0.1, uniform(0, pi))

        self.timer = rospy.Timer(rospy.Duration(5), self.timer_callback)


    def shutdown(self):
        print "Removing all objects"
        for object_name in self.objects:
            self.delete_model(object_name)

    def timer_callback(self, event):
        for obj in self.spawned_objects:
            object_state = self.get_model_state(obj, "world")
            position = object_state.pose.position
            
            if position.x < -4 and position.x > -5 and position.y < -4 and position.y > -5 and position.z < 0.08:
                self.delete_model(obj)   
                self.spawned_objects.remove(obj)

        if len(self.spawned_objects) == 0:
            rospy.signal_shutdown("no more objects")


    def spawn_object(self, object_name, x, y, z, rotation):
        path = self.rospack.get_path("arm_gazebo")
        with open(path +  "/sdf/" + str(object_name) + ".sdf") as f:
            box_xml = f.read()
            
        orientation = Quaternion()
        quaternion = tf.transformations.quaternion_from_euler(0, 0, rotation)
        orientation.x = quaternion[0]
        orientation.y = quaternion[1]
        orientation.z = quaternion[2]
        orientation.w = quaternion[3]
        
        pose = Pose(Point(x, y, z), orientation)
        
        self.spawn_model(object_name, box_xml, "", pose, "world")            
        
if __name__ == "__main__":
    rospy.init_node("set_objects")
    object_manager = ObjectManager() 
    rospy.spin()