#! /usr/bin/python
import rospy 
from order.msg import Order

rospy.init_node("receive_order_example")
while not rospy.is_shutdown(): # While loop represents your behaviours update loop, DO NOT COPY THE WHILE LOOP IN YOUR BEHAVIOUR

  try:
    order_msg = rospy.wait_for_message("/order", Order, 0.5) # Wait for 0.5 seconds to receive something

    print order_msg.objects # Print the objects
    break # Break for breaking out of the while loop to quit this example script, your behaviour should now continue. 
  except:
    pass # When nothing received, do nothing, it will repeat listening to a message
