from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy
from order.msg import Order

class receive_order(AbstractBehaviour):

    def init(self):
        self.order_list = None

    def update(self):

        try:
            order_msg = rospy.wait_for_message("/order", Order, 0.5) # Wait for 0.5 seconds to receive something
            self.order_list = order_msg.objects
            #print "Received order: " + str(order_msg.objects)
            self.finish()

        except:
            self.fail('Receiving order failed')
 
    def reset(self):
        self.state = State.idle
        self.init()