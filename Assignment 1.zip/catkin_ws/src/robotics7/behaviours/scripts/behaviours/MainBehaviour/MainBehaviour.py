from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
import rospy


class MainBehaviour(AbstractBehaviour):
    
    def init(self):
        print('Initializing States')
        self.receive_sub = self.get_behaviour('receive_order')
        self.navigate_sub = self.get_behaviour('navigate')
        self.approach_sub = self.get_behaviour('approach')
        self.grasp_sub = self.get_behaviour('grasp')
        self.drop_sub = self.get_behaviour('drop')
        self.recognize_sub = self.get_behaviour('recognize')

        self.order_list = None
        self.success_list = []
        self.starting_location = "Start"
        self.goal_locations = ["A", "B"]
        self.dropoff_location = "C"
        self.target_object = None
        self.grasped = False
        self.last_state = None

    def update(self):

        if self.state != self.last_state:
            print 'Machine in state: ' + str(self.state)
            self.last_state = self.state

        # START
        if self.state == State.start:
            self.set_state(State.receive_order)
            self.receive_sub.start()

        # RECEIVE
        elif self.state == State.receive_order:
            if self.receive_sub.finished():
                # Receive the list of objects, in order, to be collected
                self.order_list = self.receive_sub.order_list
                self.receive_sub.reset()

                # Received order, navigate to first goal location
                self.set_state(State.navigate)
                self.navigate_sub.set_goal_location(self.goal_locations[0])
                self.navigate_sub.start()

            elif self.receive_sub.failed():
                self.receive_sub.reset()
                self.receive_sub.start()

        # NAVIGATE
        elif self.state == State.navigate:
            if self.navigate_sub.finished():
                self.navigate_sub.reset()

                # If robot has grasped an object
                # Navigated to dropoff location, go to drop
                if self.grasped:
                    self.set_state(State.drop)
                    self.drop_sub.start()

                # If robot has no object in hand and there are no more locations to be visited
                # Robot returned to starting location
                elif not self.grasped and len(self.goal_locations) == 0:
                    print "Successfully grasped and dropped: " + str(self.success_list)
                    self.reset_goals()
                    self.set_state(State.start)

                # First time the program initiates, it starts here.
                # Navigated to goal location, start approach
                else:
                    self.goal_locations = self.goal_locations[1:]
                    self.set_state(State.approach)
                    self.approach_sub.start()

            elif self.navigate_sub.failed():
                self.navigate_sub.reset()

                # If navigation fails
                # Navigate to starting point, state stays the same
                self.navigate_sub.set_goal_location(self.starting_location)
                self.navigate_sub.start()

        # APPROACH
        elif self.state == State.approach:
            if self.approach_sub.finished():
                self.approach_sub.reset()

                # Approach successful, go to recognize
                self.set_state(State.recognize)
                self.recognize_sub.start()

            elif self.approach_sub.failed():
                self.approach_sub.reset()

                # Approach failed, go back to navigate
                self.set_state(State.navigate)
                self.navigate_sub.start()

        # RECOGNIZE
        elif self.state == State.recognize:
            if self.recognize_sub.finished():
                # Get object as string
                obj = str(self.recognize_sub.object).split()[1]
                obj = obj.strip().replace('"', '')
                self.recognize_sub.reset()
                
                # If the object is in the list of objects to be grasped, go to grasp
                if obj in str(self.order_list):
                    self.set_state(State.grasp)
                    self.grasp_sub.start()
                    self.order_list.remove(obj)
                    self.target_object = obj

                # If object is not in the list, go back to navigation to visit the next location
                # Continue with next goal location
                elif len(self.goal_locations) != 0 and len(self.order_list) != 0:
                    self.set_state(State.navigate)
                    self.navigate_sub.set_goal_location(self.goal_locations[0])
                    self.navigate_sub.start()

                # Object not in order list and all locations visited, return to starting location
                else:
                    self.set_state(State.navigate)
                    self.navigate_sub.set_goal_location(self.starting_location)
                    self.navigate_sub.start()

            elif self.recognize_sub.failed():
                self.recognize_sub.reset()

                # Try again!
                self.recognize_sub.start()

        # GRASP
        elif self.state == State.grasp:
            if self.grasp_sub.finished():
                self.grasp_sub.reset()

                # Object grasped, navigate to dropoff location
                self.grasped = True
                self.set_state(State.navigate)
                self.navigate_sub.set_goal_location(self.dropoff_location)
                self.navigate_sub.start()

            elif self.grasp_sub.failed():
                self.grasp_sub.reset()

                # Try again
                self.grasp_sub.start()

        # DROP
        elif self.state == State.drop:
            if self.drop_sub.finished():
                self.drop_sub.reset()
                self.grasped = False

                # Record success
                self.success_list.append(self.target_object)
                self.target_object = None

                # Continue with next goal location
                if len(self.goal_locations) != 0 and len(self.order_list) != 0:
                    self.set_state(State.navigate)
                    self.navigate_sub.set_goal_location(self.goal_locations[0])
                    self.navigate_sub.start()

                # Dropped object and all locations visited, return to starting location
                else:
                    self.set_state(State.navigate)
                    self.navigate_sub.set_goal_location(self.starting_location)
                    self.navigate_sub.start()

            elif self.drop_sub.failed():
                self.drop_sub.reset()

                # Try again
                self.drop_sub.start()


        else:
            pass


    def reset_goals(self):
        self.order_list = None
        self.success_list = []
        self.starting_location = "Start"
        self.goal_locations = ["A", "B"]
        self.dropoff_location = "C"
        self.target_object = None
        self.grasped = False
