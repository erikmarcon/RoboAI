from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
from fake_manipulation.msg import FakeDropAction, FakeDropResult, FakeDropGoal
import actionlib
import rospy


class drop(AbstractBehaviour):
    
    def init(self):
        self.client = actionlib.SimpleActionClient("/drop", FakeDropAction)
        self.client.wait_for_server()
        self.goal = None


    def update(self):
        if self.goal is None:
            self.goal = FakeDropGoal()
            self.client.send_goal(self.goal)

        if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            #print "Dropping succeeded"
            self.finish()

        elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
            #print "Dropping failed"
            self.fail('Dropping Failed')
    
    def reset(self):
        self.state = State.idle
        self.init()