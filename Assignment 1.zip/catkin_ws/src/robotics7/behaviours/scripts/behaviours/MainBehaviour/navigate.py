from utils.abstractBehaviour import AbstractBehaviour
from utils.state import State
import actionlib
import rospy
from fake_navigation.msg import FakeNavigationAction, FakeNavigationActionGoal
import time


class navigate(AbstractBehaviour):
    
    def init(self):
        self.client = actionlib.SimpleActionClient("/navigate", FakeNavigationAction)
        self.client.wait_for_server()
        self.goal = None
        self.goal_location = None


    def update(self):
        if self.goal is None:
            self.goal = FakeNavigationActionGoal()
            self.goal.goal = self.goal_location
            self.client.send_goal(self.goal)

        if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            #print "Navigation succeeded"
            self.finish()

        elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
            #print "Navigation failed"
            self.fail('Navigation Failed')

    def set_goal_location(self, goal):
        self.goal_location = goal
              
    def reset(self):
        self.state = State.idle
        self.init()
