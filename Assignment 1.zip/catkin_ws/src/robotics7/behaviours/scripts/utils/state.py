from enum import Enum, unique

@unique
class State(Enum):
    idle = 0
    start = 1
    finished = 2
    failed = 3
    # Add the states of the FSM => SubBehaviours
    receive_order = 4
    navigate = 5
    approach = 6
    recognize = 7
    grasp = 8
    drop = 9
