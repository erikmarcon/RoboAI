#include "bounding_box_server/bounding_box_server.h"

//! Removes a flat surface from the Point Cloud.
/**
 * Removes 1 flat surface, which should be the floor, from the Point Cloud. It uses RANSAC to find points belonging to a possible 
 * planar surface, and checks if the points lay within a threshold to determine if it belongs to the surface or not. 
 * \param point_cloud Pointer to the input Point Cloud, should only contain one large planar surface (the floor).
 * \param floorless_point_cloud Pointer to the Point Cloud without a floor surface in it.
 * \param distance_threshold determines the threshold in meters when a points belongs to a possible planar surface or not.
 */
void BoundingBoxServer::removeFloor(PointCloudPtr point_cloud, PointCloudPtr floorless_point_cloud, float distance_threshold) {
  pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients); 
  pcl::PointIndices::Ptr inliers(new pcl::PointIndices); 

  /*
  sac_segmentation_ is a pcl::SACSegmentation<Point> class object, 
  https://pointclouds.org/documentation/classpcl_1_1_s_a_c_segmentation.html

  Which inherits the PCLBase class
  https://pointclouds.org/documentation/classpcl_1_1_p_c_l_base.html

  - You need to set the input point cloud, point_cloud.
  - You need to set a distance threshold, distance_threshold, how close is a point when it still belongs to the surface
  - Set the method type to pcl::SAC_RANSAC
  - Set the model type to pcl::SACMODEL_PLANE
  - Segment using the inliers and coefficients objects (they are pointers so use a * before the name)
    Whilst both parameters are required, only inliers will be used later
    The inliers object should now contain all the indexes of the points that are part of the floor 
  */

  /* 
  extract_indices_ is a pcl::ExtractIndices<Point> class object,
  https://pointclouds.org/documentation/classpcl_1_1_extract_indices.html

  which inherits the PCLBase class,

  and the pcl::FilterIndices<Point> class,
  https://pointclouds.org/documentation/classpcl_1_1_filter_indices.html

  - You need to set the input point cloud
  - You need to set the indicies 
  - You need to set whether to keep the indices, or remove the indices from the point cloud
  - Filter the point cloud, and write the new point cloud to *floorless_point_cloud

  */
}

//! Given a Point Cloud, extract the clusters as separate Point Clouds.
/**
 * Given a Point Cloud extract the clusters and put them in their own Point Cloud. 
 * \param point_cloud Pointer to the input Point Cloud. The Point Cloud should have the floor surface removed.
 * \param clusters a vector of Pointers to Point Clouds, each Point Cloud represents a cluster.
 * \param cluster_tolerance the distance between two points that indicates when they become their separate cluster.
 */
void BoundingBoxServer::extractClusters(PointCloudPtr point_cloud, std::vector<PointCloudPtr> &clusters, float cluster_tolerance) {
  pcl::search::KdTree<Point>::Ptr search_tree(new pcl::search::KdTree<Point>()); // Used for quickly searching the Point Cloud structure
  search_tree->setInputCloud(point_cloud); // Pointer to the input Point Cloud 

  std::vector<pcl::PointIndices> cluster_indices;
  
  /*
  cluster_extraction_ is a pcl::EuclideanClusterExtraction<Point> class object,
  https://pointclouds.org/documentation/classpcl_1_1_euclidean_cluster_extraction.html

  which inherits the PCLBase class,
  https://pointclouds.org/documentation/classpcl_1_1_p_c_l_base.html

  - Set the input point cloud, point_cloud
  - Set the search method, search_tree
  - Set the cluster tolerance, cluster_tolerance
  - Set the min and max cluster sizes, recommended between 10 and 50000
  - Extract the clusters with the parameter, cluster_indices

    cluster_indices is now a vector, where each items is another vector of all the indices that belong to a single cluster
  */

  /*
  for each cluster in cluster_indices, do 
    - create a new point cloud pointer: PointCloudPtr cluster_cloud(new PointCloud())

    for each index value of the PointIndices, do 
      - add the point at position index, from the point_cloud, to the cluster_cloud.
      You can access the points via e.g. point_cloud->points, points is a vector, from which you can get an item via index, points[index], 
      or add a new item at the back, points.push_back(point)

    Add the newly create cluster_cloud to the clusters vector (parameter for the function), use push_back
  */
}

//! Isolates the top surface of a cluster
/**
 * Uses pcl::getMinMax3D to determine the max z-axis value in the cluster. 
 * Next, passThroughFilter is used to isolate the top part in the cluster within the specified range
 * \param point_cloud Pointer to the input cloud
 * \param point_cloud_top_surface Pointer to the output cloud
 * \param top_slice_size The z-axis range that gets passed through by the filter
 */
void BoundingBoxServer::getTopSurface(PointCloudPtr point_cloud, PointCloudPtr point_cloud_top_surface, float top_slice_size) {
  /*
  There exists a typedef for a pcl::PointT, named Point
  There exists a function pcl::getMinMax3D to get the min and max values of the point cloud,
  https://pointclouds.org/documentation/group__common.html#ga3166f09aafd659f69dc75e63f5e10f81

  Use the member function passTroughFilter to isolate the top surface of the input cloud
  */
}

//! Function to project the Point Cloud on the planar surface.
/** 
 * Will project all the points to have a zero z value. 
 * \param point_cloud Pointer to the input Point Cloud.
 * \param projected_point_cloud Pointer to the Point Cloud that should contain the projected point_cloud on the planar surface.
 */
void BoundingBoxServer::projectPointCloudOnPlane(PointCloudPtr point_cloud, PointCloudPtr projected_point_cloud) {
  pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients());
  coefficients->values.resize(4);
  coefficients->values[0] = coefficients->values[1] = coefficients->values[3] = 0.0f;
  coefficients->values[2] = 1.0f; // Z-axis 

  /*
  project_inliers_ is a pcl::ProjectInliers<Point> class object,
  https://pointclouds.org/documentation/classpcl_1_1_project_inliers.html

  Which inherits from PCLBase<Point>,
  https://pointclouds.org/documentation/classpcl_1_1_p_c_l_base.html

  - Set the input cloud, point_cloud
  - Set the model type, pcl::SACMODEL_PLANE
  - Set the coefficients, coefficients
  - Filter the point cloud, use *projected_point_cloud
  */ 
}

//! Get the eigen vectors of a Point Cloud.
/**
 * Assumes the Point Cloud has been projected to the planar surface in order to work correctly.
 * \param point_cloud Pointer to a Point Cloud that has been project on a planar surface.
 * \return A matrix containing the 3 eigen vectors in each column.
 */ 
Eigen::Matrix3f BoundingBoxServer::getEigenVectors(PointCloudPtr point_cloud) {
  /*
  pca_ is a pcl::PCA<Point> class object,
  https://pointclouds.org/documentation/classpcl_1_1_p_c_a.html

  Which inherits from PCLBase<Point>,
  https://pointclouds.org/documentation/classpcl_1_1_p_c_l_base.html

  - Set the input cloud, point_cloud
  - Return the eigenvectors 
  */
}

//! Get the angle between the eigen vector and a (1,0) vector.
/** 
 * Calculate the angle between two vectors, base_vector is a vector (1,0) representing the direction of the arm base.
 * \param eigen_vector the eigen vector from the object representing the yaw rotation.
 * \return the angle between the base_vector (1,0) and the eigen_vector.
 */
float BoundingBoxServer::getAngle(Eigen::Vector3f eigen_vector) {
  Eigen::Vector2f object_vector = eigen_vector.head<2>();
  Eigen::Vector2f base_vector;
  base_vector << 1.0f, 0.0f; // x = 1.0, y = 0.0

  /* 
  Return the angle between the object_vector and base_link_vector.
  Note: the angle can be between -pi and pi. 
  */
}

//! Get the center point of the given Point Cloud.
/**
 * Calculate and return the center point (x, y, z) of the given Point Cloud.
 * \param point_cloud Pointer to the input Point Cloud.
 * \return vector containing the center x, y, z coordinates.
 */
Eigen::Vector3f BoundingBoxServer::getCenterPointCloud(PointCloudPtr point_cloud) {
  /*
  There exists a typedef for a pcl::PointT, named Point
  There exists a function pcl::getMinMax3D to get the min and max values of the point cloud,
  https://pointclouds.org/documentation/group__common.html#ga3166f09aafd659f69dc75e63f5e10f81

  Create an Eigen::Vector3f centroid_vector; 
  Assign the center of the point cloud to the centroid_vector.
  Either by centroid_vector << x, y, z; 
  or centroid_vector.x() = x;
  centroid_vector.y() = y;
  centroid.vector.z() = z;

  Return the centroid_vector
  */
}

//! Gets the dimensions length, width, height of the given Point Cloud.
/**
 * Calculates the min and max points, from which it extract the center of each axis.
 * \param point_cloud Pointer to the input Point Cloud of which to calculate the dimensions, the Point Cloud should have been transformed to the origin.
 * \param bounding_box the return value to include the length, width, and height of point_cloud.
 */
void BoundingBoxServer::getDimensions(PointCloudPtr point_cloud, bounding_box_server::BoundingBox &bounding_box) {
  /*
  There exists a typedef for a pcl::PointT, named Point
  There exists a function pcl::getMinMax3D to get the min and max values of the point cloud,
  https://pointclouds.org/documentation/group__common.html#ga3166f09aafd659f69dc75e63f5e10f81

  assign the length, x axis, to bounding_box.length
  assign the width, y axis, to bounding_box.width
  assign the height, z axis, to bounding_box.height
  */
}
