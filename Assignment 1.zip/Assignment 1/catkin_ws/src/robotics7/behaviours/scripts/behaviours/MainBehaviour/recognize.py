from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
from fake_object_recognition.msg import FakeObjectRecognitionAction, FakeObjectRecognitionResult, FakeObjectRecognitionActionGoal
import rospy
import actionlib


class recognize(AbstractBehaviour):
    
    def init(self):
        self.client = actionlib.SimpleActionClient("object_recognition", FakeObjectRecognitionAction)
        self.client.wait_for_server()
        self.goal = None
        self.object = None

    def update(self):
        if self.goal is None:
            self.goal = FakeObjectRecognitionActionGoal()
            self.client.send_goal(self.goal)

        if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            #print self.client.get_result()
            self.object = self.client.get_result()
            #print "Recognition succeeded"
            self.finish()

        elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
            #print "Recognition failed"
            self.fail('Recognition failed')



    
    def reset(self):
        self.state = State.idle
        self.init()