from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
from fake_manipulation.msg import FakeGraspAction, FakeGraspResult, FakeGraspGoal
import actionlib
import rospy


class grasp(AbstractBehaviour):
    
    def init(self):
        self.client = actionlib.SimpleActionClient("/grasp", FakeGraspAction)
        self.client.wait_for_server()
        self.goal = None


    def update(self):
        if self.goal is None:
            self.goal = FakeGraspGoal()
            self.client.send_goal(self.goal)

        if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            #print "Grasping succeeded"
            self.finish()

        elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
            #print "Grasping failed"
            self.fail('Grasping Failed')
    
    def reset(self):
        self.state = State.idle
        self.init()