from utils.state import State
from utils.abstractBehaviour import AbstractBehaviour
from approach_objects.msg import ApproachObjectAction, ApproachObjectGoal, ApproachObjectResult
import actionlib
import rospy


class approach(AbstractBehaviour):
    
    def init(self):
        self.client = actionlib.SimpleActionClient("/approach_objects", ApproachObjectAction)
        self.client.wait_for_server()
        self.goal = None

    def update(self):
        if self.goal is None:
            self.goal = ApproachObjectGoal()
            self.client.send_goal(self.goal)


        if self.client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            #print "Approach succeeded"
            self.finish()

        elif self.client.get_state() == actionlib.GoalStatus.ABORTED:
            #print "Approach failed"
            self.fail('Approach failed')

    
    def reset(self):
        self.state = State.idle
        self.init()