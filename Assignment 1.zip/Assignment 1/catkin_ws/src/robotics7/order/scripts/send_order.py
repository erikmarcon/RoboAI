#! /usr/bin/python
import rospy
from order.msg import Order

rospy.init_node("send_order_example")
order_publisher = rospy.Publisher("/order", Order, queue_size=1)
rospy.sleep(2) # Give ros some time to initalize and register the publisher

order_msg = Order()
# Example of sending two objects, the order is just a list of strings of the objects
order_msg.objects = ["bluebox", "yellowbox"]

for i in range(10): # Send it multiple times, behaviour might not be listening just yet.
  order_publisher.publish(order_msg)
  rospy.sleep(0.1)
